import fs from 'fs';
import path from 'path';
import { LifeTask } from '../src/types';
import { INITIAL_SAMPLE_TASKS } from '../src/data/initialTasks';

const DATA_DIR = path.join(process.cwd(), 'data');
const TASKS_FILE = path.join(DATA_DIR, 'stored_tasks.json');

// Ensure data directory exists
function ensureDataDir(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  } catch (err) {
    console.error('Error creating data directory:', err);
  }
}

// Read tasks from disk
export async function getStoredTasks(): Promise<LifeTask[]> {
  ensureDataDir();
  try {
    if (fs.existsSync(TASKS_FILE)) {
      const data = await fs.promises.readFile(TASKS_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Error reading stored tasks, using initial sample data:', err);
  }

  // If file doesn't exist or failed to parse, initialize with sample tasks
  const initial = INITIAL_SAMPLE_TASKS;
  await saveStoredTasks(initial);
  return initial;
}

// Write tasks to disk safely
export async function saveStoredTasks(tasks: LifeTask[]): Promise<boolean> {
  ensureDataDir();
  try {
    const tempFile = `${TASKS_FILE}.tmp.${Date.now()}`;
    await fs.promises.writeFile(tempFile, JSON.stringify(tasks, null, 2), 'utf-8');
    await fs.promises.rename(tempFile, TASKS_FILE);
    return true;
  } catch (err) {
    console.error('Error saving tasks to disk:', err);
    try {
      await fs.promises.writeFile(TASKS_FILE, JSON.stringify(tasks, null, 2), 'utf-8');
      return true;
    } catch (fallbackErr) {
      console.error('Fallback save failed:', fallbackErr);
      return false;
    }
  }
}

// Add a single task
export async function addStoredTask(task: LifeTask): Promise<LifeTask[]> {
  const current = await getStoredTasks();
  const updated = [task, ...current.filter((t) => t.id !== task.id)];
  await saveStoredTasks(updated);
  return updated;
}

// Add multiple tasks
export async function addMultipleStoredTasks(newTasks: LifeTask[]): Promise<LifeTask[]> {
  const current = await getStoredTasks();
  const newIds = new Set(newTasks.map((t) => t.id));
  const updated = [...newTasks, ...current.filter((t) => !newIds.has(t.id))];
  await saveStoredTasks(updated);
  return updated;
}

// Update a task
export async function updateStoredTask(id: string, updates: Partial<LifeTask>): Promise<{ updatedTask: LifeTask | null; tasks: LifeTask[] }> {
  const current = await getStoredTasks();
  let updatedTask: LifeTask | null = null;
  const updated = current.map((task) => {
    if (task.id === id) {
      updatedTask = { ...task, ...updates };
      return updatedTask;
    }
    return task;
  });

  if (updatedTask) {
    await saveStoredTasks(updated);
  }
  return { updatedTask, tasks: updated };
}

// Delete a task
export async function deleteStoredTask(id: string): Promise<LifeTask[]> {
  const current = await getStoredTasks();
  const updated = current.filter((task) => task.id !== id);
  await saveStoredTasks(updated);
  return updated;
}

// Reset sample tasks while preserving user-created tasks
export async function resetStoredTasks(): Promise<LifeTask[]> {
  const current = await getStoredTasks();
  // Filter out any user-created tasks so they are never lost on sample reset
  const userCreatedTasks = current.filter(
    (t) => t && t.isSample === false && !t.id.startsWith('task-sample-')
  );
  
  // Re-seed fresh initial sample tasks
  const sampleTasks = INITIAL_SAMPLE_TASKS.map((task) => ({
    ...task,
    isSample: true,
    source: (task.source || 'sample') as any,
  }));

  const merged = [...userCreatedTasks, ...sampleTasks];
  await saveStoredTasks(merged);
  return merged;
}
