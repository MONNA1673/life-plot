import { LifeCategory, ParsedTaskResult, Priority, ReminderSetting } from '../types';
import { formatDateToISO } from './dateUtils';
import { createReminderInfo } from './reminderUtils';

/**
 * Intelligent client-side heuristic parser for natural language life admin tasks.
 * Serves as an instant fallback or pre-parser when offline.
 */
export function heuristicParseTask(input: string, referenceDate: Date = new Date()): ParsedTaskResult {
  const text = input.trim();
  const lower = text.toLowerCase();

  // 0. Detect Reminder Request
  let reminderSetting: ReminderSetting = 'none';
  if (/remind me in 2 min|in 2 minutes|in 2 mins|2 minute reminder|2 min reminder|test reminder|remind me in 2m\b/i.test(lower)) {
    reminderSetting = 'in_2_minutes';
  } else if (/remind me 1 day before|remind me a day before|1 day before reminder|day prior reminder/i.test(lower)) {
    reminderSetting = '1_day_before';
  } else if (/remind me 1 hour before|remind me an hour before|1 hour before reminder|1 hr before/i.test(lower)) {
    reminderSetting = '1_hour_before';
  } else if (/remind me on the day|remind me day of|on due date reminder/i.test(lower)) {
    reminderSetting = 'on_due_date';
  } else if (/^remind me\b|please remind me\b|reminder:|set a reminder/i.test(lower)) {
    // If "remind me to..." is used, set reminder on due date
    reminderSetting = 'on_due_date';
  }

  // 1. Detect Category
  let category: LifeCategory = 'Other';
  if (/car|registration|dmv|smog|vehicle|oil change|tire|mechanic|driver license|license plate|auto insurance/i.test(lower)) {
    category = 'Vehicles & DMV';
  } else if (/dentist|doctor|appointment|prescription|refill|pediatrician|checkup|therapy|optometrist|eye exam|medication|vaccine|dental|teeth/i.test(lower)) {
    category = 'Health & Medical';
  } else if (/tax|taxes|irs|w-2|1099|deductible|budget|bank|credit card|invest|invoice|expense|mortgage|bill|pay slip/i.test(lower)) {
    category = 'Finance & Taxes';
  } else if (/hvac|plumber|electrician|lease|landlord|rent|clean|gutter|roof|mow|ac filter|water heater|appliance|home repair/i.test(lower)) {
    category = 'Home & Utilities';
  } else if (/school|daycare|kid|kids|child|daughter|son|tutor|field trip|parent-teacher|summer camp/i.test(lower)) {
    category = 'Family & Kids';
  } else if (/meeting|boss|resume|linkedin|presentation|client|quarterly report|performance review|career/i.test(lower)) {
    category = 'Career & Work';
  } else if (/passport|visa|notary|court|attorney|will|insurance policy|contract|legal|renew license/i.test(lower)) {
    category = 'Legal & Admin';
  } else if (/vacation|flight|hotel|birthday|gift|concert|gym|workout|trip|dinner reservation/i.test(lower)) {
    category = 'Personal & Leisure';
  }

  // 2. Detect Priority
  let priority: Priority = 'medium';
  if (/urgent|asap|immediately|critical|emergency|overdue|highest priority/i.test(lower)) {
    priority = 'urgent';
  } else if (/important|high priority|must do|critical deadline|soon as possible/i.test(lower)) {
    priority = 'high';
  } else if (/low priority|someday|when possible|whenever|nice to have|leisure/i.test(lower)) {
    priority = 'low';
  }

  // 3. Detect Recurrence
  let recurrence: 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly' = 'none';
  if (/every year|annually|yearly|annual/i.test(lower)) recurrence = 'yearly';
  else if (/every month|monthly/i.test(lower)) recurrence = 'monthly';
  else if (/every week|weekly/i.test(lower)) recurrence = 'weekly';
  else if (/every day|daily/i.test(lower)) recurrence = 'daily';

  // 4. Parse Date
  const targetDate = new Date(referenceDate);
  const currentYear = referenceDate.getFullYear();
  const currentMonth = referenceDate.getMonth(); // 0-indexed

  const monthNames = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
  const monthAbbr = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'sept', 'oct', 'nov', 'dec'];

  let matchedDate = false;

  // Pattern: "today"
  if (/\btoday\b/i.test(lower)) {
    // targetDate is today
    matchedDate = true;
  }
  // Pattern: "tomorrow"
  else if (/\btomorrow\b/i.test(lower)) {
    targetDate.setDate(targetDate.getDate() + 1);
    matchedDate = true;
  }
  // Pattern: "in X days"
  else if (/in (\d+) days?/i.test(lower)) {
    const match = lower.match(/in (\d+) days?/i);
    if (match) {
      targetDate.setDate(targetDate.getDate() + parseInt(match[1], 10));
      matchedDate = true;
    }
  }
  // Pattern: "in X weeks"
  else if (/in (\d+) weeks?/i.test(lower)) {
    const match = lower.match(/in (\d+) weeks?/i);
    if (match) {
      targetDate.setDate(targetDate.getDate() + parseInt(match[1], 10) * 7);
      matchedDate = true;
    }
  }
  // Pattern: "next week"
  else if (/next week/i.test(lower)) {
    targetDate.setDate(targetDate.getDate() + 7);
    matchedDate = true;
  }
  // Pattern: "next [day of week]" or "[day of week]" (e.g. "next Tuesday", "this Friday")
  else {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    for (let i = 0; i < days.length; i++) {
      const dayName = days[i];
      const nextDayRegex = new RegExp(`(?:next|this)?\\s*${dayName}`, 'i');
      if (nextDayRegex.test(lower)) {
        const currentDayIndex = referenceDate.getDay();
        let diff = i - currentDayIndex;
        if (diff <= 0) diff += 7;
        if (/next\s+/i.test(lower) && diff < 7) diff += 7;
        targetDate.setDate(targetDate.getDate() + diff);
        matchedDate = true;
        break;
      }
    }
  }

  // Pattern: Specific Month mentioned (e.g. "in November", "by November 15", "Nov 20")
  if (!matchedDate) {
    for (let m = 0; m < 12; m++) {
      const full = monthNames[m];
      const abbr = monthAbbr[m];
      const monthRegex = new RegExp(`\\b(?:in|by|on|during|before)?\\s*(${full}|${abbr})(?:\\s+(\\d{1,2})(?:st|nd|rd|th)?)?(?:\\s*,?\\s*(\\d{4}))?\\b`, 'i');
      const match = lower.match(monthRegex);
      if (match) {
        let year = match[3] ? parseInt(match[3], 10) : currentYear;
        const targetMonth = m;
        // If the month is earlier in the year than current month and no year specified, assume next year
        if (!match[3] && targetMonth < currentMonth) {
          year = currentYear + 1;
        }
        const day = match[2] ? parseInt(match[2], 10) : 15; // default mid-month if day not specified
        targetDate.setFullYear(year, targetMonth, day);
        matchedDate = true;
        break;
      }
    }
  }

  // If no date detected, default to 3 days from now
  if (!matchedDate) {
    targetDate.setDate(targetDate.getDate() + 3);
  }

  // 5. Clean Clean Title
  let cleanedTitle = text
    .replace(/^remind me to\s+/i, '')
    .replace(/^i need to\s+/i, '')
    .replace(/^please remind me to\s+/i, '')
    .replace(/^remember to\s+/i, '')
    .replace(/^don't forget to\s+/i, '')
    .replace(/^have to\s+/i, '')
    .replace(/^schedule\s+/i, 'Schedule ')
    .trim();

  // Capitalize first letter
  if (cleanedTitle.length > 0) {
    cleanedTitle = cleanedTitle.charAt(0).toUpperCase() + cleanedTitle.slice(1);
  }

  // 6. Pre-generate helpful checklist & tips based on domain
  let checklist: string[] = [];
  let prepTips: string[] = [];

  if (category === 'Vehicles & DMV') {
    checklist = ['Locate vehicle title / renewal notice', 'Verify current smog check status', 'Pay fee online or visit local kiosk'];
    prepTips = ['Have your License Plate & last 5 digits of VIN ready'];
  } else if (category === 'Health & Medical') {
    checklist = ['Confirm insurance policy ID', 'Prepare list of current symptoms/questions', 'Add calendar invite with clinic address'];
    prepTips = ['Check if in-network provider to minimize co-pay'];
  } else if (category === 'Finance & Taxes') {
    checklist = ['Gather relevant W2/1099/receipts', 'Review deduction categories', 'Schedule submission or accountant call'];
    prepTips = ['Keep digital scans of all supporting documentation'];
  } else if (category === 'Home & Utilities') {
    checklist = ['Check model/filter dimensions', 'Compare 2-3 local contractor quotes', 'Mark completion on home calendar'];
  }

  const dueDateStr = formatDateToISO(targetDate);
  const reminder = reminderSetting !== 'none' 
    ? createReminderInfo(reminderSetting, dueDateStr)
    : undefined;

  return {
    title: cleanedTitle || 'New Life Admin Task',
    dueDate: dueDateStr,
    priority,
    category,
    estimatedMinutes: category === 'Vehicles & DMV' ? 25 : category === 'Health & Medical' ? 15 : 30,
    recurrence,
    reminder,
    checklist,
    prepTips,
    notes: `Added from natural language prompt: "${text}"`,
    tags: [category.split(' ')[0].toLowerCase(), priority],
  };
}
