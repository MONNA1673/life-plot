import { ReminderInfo, ReminderSetting } from '../types';
import { parseISODate } from './dateUtils';

export interface ReminderOption {
  id: ReminderSetting;
  label: string;
  shortLabel: string;
  description: string;
}

export const REMINDER_OPTIONS: ReminderOption[] = [
  {
    id: 'none',
    label: 'None',
    shortLabel: 'None',
    description: 'Do not alert for this task',
  },
  {
    id: 'in_2_minutes',
    label: 'In 2 minutes',
    shortLabel: 'In 2 minutes',
    description: 'Triggers an in-app alert exactly 2 minutes from now',
  },
  {
    id: 'on_due_date',
    label: 'Due date',
    shortLabel: 'Due date',
    description: 'Remind on the due date (at specified due time or 9:00 AM)',
  },
  {
    id: '1_day_before',
    label: '1 day before',
    shortLabel: '1 day before',
    description: 'Remind 24 hours prior to deadline',
  },
  {
    id: '1_hour_before',
    label: 'One hour before',
    shortLabel: '1 hour before',
    description: 'Remind 1 hour before scheduled time',
  },
];

/**
 * Calculates the exact ISO datetime for when a reminder should fire.
 */
export function calculateReminderDateTime(
  dueDate: string,
  dueTime?: string,
  setting: ReminderSetting = 'on_due_date'
): string | undefined {
  if (setting === 'none') {
    return undefined;
  }

  // Handle immediate test reminder in 2 minutes
  if (setting === 'in_2_minutes') {
    return new Date(Date.now() + 2 * 60 * 1000).toISOString();
  }

  if (!dueDate) {
    return undefined;
  }

  const baseDate = parseISODate(dueDate);
  if (isNaN(baseDate.getTime())) return undefined;

  let hours = 9;
  let minutes = 0;

  if (dueTime && dueTime.includes(':')) {
    const [h, m] = dueTime.split(':').map(Number);
    if (!isNaN(h) && !isNaN(m)) {
      hours = h;
      minutes = m;
    }
  }

  baseDate.setHours(hours, minutes, 0, 0);

  if (setting === '1_day_before') {
    baseDate.setDate(baseDate.getDate() - 1);
    // If no dueTime was specified, default 1 day before to 9:00 AM
    if (!dueTime) {
      baseDate.setHours(9, 0, 0, 0);
    }
  } else if (setting === '1_hour_before') {
    // 1 hour before scheduled time
    baseDate.setHours(baseDate.getHours() - 1);
  } else if (setting === 'on_due_date') {
    // On due date (at specified due time or 9:00 AM default)
    if (!dueTime) {
      baseDate.setHours(9, 0, 0, 0);
    }
  }

  return baseDate.toISOString();
}

/**
 * Build or update ReminderInfo object
 */
export function createReminderInfo(
  setting: ReminderSetting,
  dueDate: string,
  dueTime?: string
): ReminderInfo {
  if (setting === 'none') {
    return {
      enabled: false,
      setting: 'none',
    };
  }

  const reminderDateTime = calculateReminderDateTime(dueDate, dueTime, setting);

  return {
    enabled: true,
    setting,
    reminderDateTime,
    dismissed: false,
  };
}

/**
 * Formats a friendly human string explaining when the reminder triggers.
 */
export function formatReminderSummary(reminder?: ReminderInfo): string {
  if (!reminder || !reminder.enabled || reminder.setting === 'none') {
    return 'No reminder set';
  }

  if (reminder.setting === 'in_2_minutes') {
    if (reminder.reminderDateTime) {
      const diffMs = new Date(reminder.reminderDateTime).getTime() - Date.now();
      if (diffMs > 0) {
        const totalSecs = Math.ceil(diffMs / 1000);
        if (totalSecs < 60) {
          return `In ${totalSecs}s`;
        }
        const mins = Math.ceil(diffMs / 60000);
        return `In ${mins} min${mins === 1 ? '' : 's'}`;
      }
    }
    return 'In 2 minutes';
  }

  if (reminder.setting === 'on_due_date') {
    return 'Due date';
  }
  if (reminder.setting === '1_day_before') {
    return '1 day before';
  }
  if (reminder.setting === '1_hour_before') {
    return 'One hour before';
  }

  if (reminder.reminderDateTime) {
    try {
      const d = new Date(reminder.reminderDateTime);
      if (!isNaN(d.getTime())) {
        return d.toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          hour: 'numeric',
          minute: '2-digit',
        });
      }
    } catch {
      // fallback
    }
  }

  return 'Reminder enabled';
}

/**
 * Gentle Web Audio synth chime for reminder alert.
 */
export function playReminderChime(): void {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();

    const now = ctx.currentTime;

    // First tone (G5: 783.99 Hz)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(783.99, now);
    gain1.gain.setValueAtTime(0, now);
    gain1.gain.linearRampToValueAtTime(0.18, now + 0.04);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.36);

    // Second tone (C6: 1046.50 Hz) - pleasant resolving chime
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1046.5, now + 0.15);
    gain2.gain.setValueAtTime(0, now + 0.15);
    gain2.gain.linearRampToValueAtTime(0.22, now + 0.19);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.65);

    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.15);
    osc2.stop(now + 0.66);
  } catch (e) {
    // AudioContext blocked by browser policy until user interacts, safe to ignore
  }
}

/**
 * Request notification permission if supported
 */
export async function requestBrowserNotificationPermission(): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }
  try {
    if (Notification.permission === 'granted') return true;
    if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }
  } catch (e) {
    console.warn('Notification permission request failed', e);
  }
  return false;
}

/**
 * Trigger native browser notification
 */
export function sendBrowserNotification(title: string, body: string): void {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  try {
    if (Notification.permission === 'granted') {
      new Notification(title, {
        body,
        icon: '/favicon.ico',
      });
    }
  } catch (e) {
    console.warn('Could not display system notification', e);
  }
}
