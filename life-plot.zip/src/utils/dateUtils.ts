/**
 * Date utility functions for Life Plot task management
 */

export function getTodayDateString(): string {
  const now = new Date();
  return formatDateToISO(now);
}

export function formatDateToISO(date: Date): string {
  if (!date || isNaN(date.getTime())) {
    const fallback = new Date();
    const y = fallback.getFullYear();
    const m = String(fallback.getMonth() + 1).padStart(2, '0');
    const d = String(fallback.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function parseISODate(dateStr?: string | null): Date {
  if (!dateStr || typeof dateStr !== 'string') return new Date();
  const cleanStr = dateStr.includes('T') ? dateStr.split('T')[0] : dateStr;
  const parts = cleanStr.split('-');
  if (parts.length === 3) {
    const y = Number(parts[0]);
    const m = Number(parts[1]);
    const d = Number(parts[2]);
    if (!isNaN(y) && !isNaN(m) && !isNaN(d) && y > 1000 && m >= 1 && m <= 12 && d >= 1 && d <= 31) {
      return new Date(y, m - 1, d);
    }
  }
  const fallback = new Date(dateStr);
  return isNaN(fallback.getTime()) ? new Date() : fallback;
}

export function formatFriendlyDate(dateStr?: string | null): string {
  if (!dateStr || typeof dateStr !== 'string') return 'No due date';
  const target = parseISODate(dateStr);
  if (isNaN(target.getTime())) return 'No due date';
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  target.setHours(0, 0, 0, 0);

  const diffTime = target.getTime() - today.getTime();
  const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

  if (isNaN(diffDays)) return dateStr;
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Tomorrow';
  if (diffDays === -1) return 'Yesterday';
  if (diffDays > 1 && diffDays <= 6) {
    return target.toLocaleDateString('en-US', { weekday: 'long' });
  }

  // Format as "MMM d, yyyy" or "MMM d" if current year
  const isSameYear = target.getFullYear() === today.getFullYear();
  return target.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: isSameYear ? undefined : 'numeric',
  });
}

export function getDaysDifference(dateStr?: string | null): number {
  if (!dateStr || typeof dateStr !== 'string') return 999;
  const target = parseISODate(dateStr);
  if (isNaN(target.getTime())) return 999;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  target.setHours(0, 0, 0, 0);

  const diffTime = target.getTime() - today.getTime();
  const diff = Math.round(diffTime / (1000 * 60 * 60 * 24));
  return isNaN(diff) ? 999 : diff;
}

export function getDateHorizon(dateStr?: string | null): 'overdue' | 'today' | 'tomorrow' | 'this_week' | 'next_week' | 'this_month' | 'future' {
  const diff = getDaysDifference(dateStr);
  if (diff < 0) return 'overdue';
  if (diff === 0) return 'today';
  if (diff === 1) return 'tomorrow';
  if (diff <= 7) return 'this_week';
  if (diff <= 14) return 'next_week';
  if (diff <= 30) return 'this_month';
  return 'future';
}

export function addDaysToDate(dateStr: string, daysToAdd: number): string {
  const current = parseISODate(dateStr);
  current.setDate(current.getDate() + daysToAdd);
  return formatDateToISO(current);
}
