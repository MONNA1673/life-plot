import React from 'react';
import { BellRing, Check, Clock, X, Calendar, ArrowRight } from 'lucide-react';
import { LifeTask } from '../types';
import { formatFriendlyDate } from '../utils/dateUtils';

interface ActiveReminderBannerProps {
  reminders: LifeTask[];
  onDismiss: (taskId: string) => void;
  onSnooze: (taskId: string, minutes?: number) => void;
  onComplete: (taskId: string) => void;
  onViewTask?: (task: LifeTask) => void;
}

export const ActiveReminderBanner: React.FC<ActiveReminderBannerProps> = ({
  reminders,
  onDismiss,
  onSnooze,
  onComplete,
  onViewTask,
}) => {
  if (!reminders || reminders.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-md w-full sm:w-auto">
      {reminders.map((task) => (
        <div
          key={`reminder-banner-${task.id}`}
          id={`reminder-banner-${task.id}`}
          className="bg-slate-900 dark:bg-slate-800 text-white p-4 rounded-2xl shadow-2xl border border-indigo-500/40 animate-in slide-in-from-bottom-5 duration-200"
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-indigo-600/30 text-indigo-400 border border-indigo-500/30 shrink-0">
              <BellRing className="w-5 h-5 animate-pulse" />
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-indigo-400">
                  Task Reminder
                </span>
                <button
                  id={`dismiss-x-btn-${task.id}`}
                  type="button"
                  onClick={() => onDismiss(task.id)}
                  className="text-slate-400 hover:text-white transition-colors"
                  title="Dismiss"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <h4 className="text-sm font-semibold text-white leading-snug line-clamp-2 mb-1">
                {task.title}
              </h4>

              <div className="flex items-center gap-2 text-xs text-slate-300 mb-3">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                  Due: {formatFriendlyDate(task.dueDate)}
                  {task.dueTime && ` at ${task.dueTime}`}
                </span>
                <span>•</span>
                <span className="text-slate-400">{task.category}</span>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  id={`reminder-complete-btn-${task.id}`}
                  type="button"
                  onClick={() => onComplete(task.id)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-xs transition-colors"
                >
                  <Check className="w-3.5 h-3.5" />
                  Mark Complete
                </button>

                <button
                  id={`reminder-snooze-btn-${task.id}`}
                  type="button"
                  onClick={() => onSnooze(task.id, 60)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
                >
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  Snooze 1 hr
                </button>

                <button
                  id={`reminder-dismiss-btn-${task.id}`}
                  type="button"
                  onClick={() => onDismiss(task.id)}
                  className="px-2.5 py-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
