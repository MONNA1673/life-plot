import React, { useState, useEffect } from 'react';
import { X, Sparkles, Calendar, Tag, AlertCircle, FileText, Bell, Clock } from 'lucide-react';
import { LifeCategory, LifeTask, Priority, ReminderSetting } from '../types';
import { ALL_CATEGORIES } from '../data/categories';
import { getTodayDateString } from '../utils/dateUtils';
import { createReminderInfo, formatReminderSummary, REMINDER_OPTIONS } from '../utils/reminderUtils';

interface TaskEditModalProps {
  task: LifeTask | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedTask: LifeTask) => void;
}

export const TaskEditModal: React.FC<TaskEditModalProps> = ({
  task,
  isOpen,
  onClose,
  onSave,
}) => {
  const [title, setTitle] = useState(task?.title || '');
  const [dueDate, setDueDate] = useState(task?.dueDate || getTodayDateString());
  const [dueTime, setDueTime] = useState(task?.dueTime || '');
  const [priority, setPriority] = useState<Priority>(task?.priority || 'medium');
  const [category, setCategory] = useState<LifeCategory>(task?.category || 'Other');
  const [reminderSetting, setReminderSetting] = useState<ReminderSetting>(
    task?.reminder?.enabled && task?.reminder?.setting ? task.reminder.setting : 'none'
  );
  const [notes, setNotes] = useState(task?.notes || '');

  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setDueDate(task.dueDate || getTodayDateString());
      setDueTime(task.dueTime || '');
      setPriority(task.priority || 'medium');
      setCategory(task.category || 'Other');
      setReminderSetting(task.reminder?.enabled && task.reminder?.setting ? task.reminder.setting : 'none');
      setNotes(task.notes || '');
    }
  }, [task]);

  if (!isOpen || !task) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const reminder = reminderSetting !== 'none'
      ? createReminderInfo(reminderSetting, dueDate, dueTime || undefined)
      : { enabled: false, setting: 'none' as const };

    onSave({
      ...task,
      title: title.trim(),
      dueDate,
      dueTime: dueTime.trim() || undefined,
      priority,
      category,
      reminder,
      notes: notes.trim(),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-950/40">
          <div className="flex items-center gap-2">
            <h2 className="font-semibold text-sm text-slate-900 dark:text-slate-100 font-serif">
              Edit Task
            </h2>
          </div>
          <button
            id="close-edit-modal-btn"
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Title */}
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
              Task Title
            </label>
            <input
              id="edit-task-title-input"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              placeholder="e.g., Renew car registration"
            />
          </div>

          {/* Row: Due Date & Due Time & Priority */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" /> Due Date
              </label>
              <input
                id="edit-task-duedate-input"
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" /> Due Time <span className="text-slate-400 font-normal">(Opt)</span>
              </label>
              <input
                id="edit-task-duetime-input"
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 text-slate-400" /> Priority
              </label>
              <select
                id="edit-task-priority-select"
                value={priority}
                onChange={(e) => setPriority(e.target.value as Priority)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none capitalize"
              >
                <option value="urgent">Urgent</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
          </div>

          {/* Reminder Setting */}
          <div className="p-3 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40">
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="edit-task-reminder-select" className="font-medium text-slate-800 dark:text-slate-200 flex items-center gap-1.5 text-xs">
                <Bell className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                Reminder Alert
              </label>
              {reminderSetting !== 'none' && (
                <span className="text-[11px] font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-100/70 dark:bg-indigo-900/50 px-2 py-0.5 rounded-md">
                  {formatReminderSummary(
                    reminderSetting === 'in_2_minutes'
                      ? { enabled: true, setting: 'in_2_minutes', reminderDateTime: new Date(Date.now() + 120000).toISOString() }
                      : { enabled: true, setting: reminderSetting, reminderDateTime: dueDate }
                  )}
                </span>
              )}
            </div>

            {/* Select Dropdown */}
            <div className="mb-2">
              <select
                id="edit-task-reminder-select"
                value={reminderSetting}
                onChange={(e) => setReminderSetting(e.target.value as ReminderSetting)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              >
                {REMINDER_OPTIONS.map((option) => (
                  <option key={option.id} value={option.id}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Segmented quick selection buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
              {REMINDER_OPTIONS.map((option) => {
                const isSelected = reminderSetting === option.id;
                return (
                  <button
                    key={option.id}
                    id={`reminder-option-${option.id}`}
                    type="button"
                    onClick={() => setReminderSetting(option.id)}
                    className={`px-2 py-1.5 rounded-lg text-xs font-medium border text-center transition-all ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs ring-1 ring-indigo-500'
                        : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-700'
                    }`}
                  >
                    {option.shortLabel}
                  </button>
                );
              })}
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
              {REMINDER_OPTIONS.find((o) => o.id === reminderSetting)?.description}
            </p>
          </div>

          {/* Category */}
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
              <Tag className="w-3.5 h-3.5 text-slate-400" /> Domain Category
            </label>
            <select
              id="edit-task-category-select"
              value={category}
              onChange={(e) => setCategory(e.target.value as LifeCategory)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            >
              {ALL_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Notes */}
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-slate-400" /> Notes & Context (Optional)
            </label>
            <textarea
              id="edit-task-notes-textarea"
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add details, links, or contact numbers..."
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none"
            />
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
            <button
              id="cancel-edit-task-btn"
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              id="save-edit-task-btn"
              type="submit"
              className="px-4 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs transition-colors"
            >
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
