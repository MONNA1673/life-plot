import React, { useState } from 'react';
import { Sparkles, Mic, MicOff, ArrowRight, Layers, HelpCircle, Check, Loader2, Bell } from 'lucide-react';
import { LifeCategory, LifeTask, ParsedTaskResult, Priority, ReminderSetting } from '../types';
import { heuristicParseTask } from '../utils/naturalLanguageParser';
import { getTodayDateString } from '../utils/dateUtils';
import { CATEGORIES_CONFIG } from '../data/categories';
import { createReminderInfo } from '../utils/reminderUtils';

interface NaturalLanguageInputProps {
  onAddTask: (task: LifeTask) => void;
  onAddMultipleTasks?: (tasks: LifeTask[]) => void;
}

const EXAMPLE_PROMPTS = [
  { text: 'Remind me to renew my car registration in November', label: '🚗 Car Registration in Nov' },
  { text: 'I need to call the dentist next Tuesday', label: '🦷 Call Dentist next Tuesday' },
  { text: 'Pay quarterly estimated tax by Sept 15', label: '📄 Quarterly Tax by Sept 15' },
  { text: 'Replace furnace HVAC filters next week', label: '🏡 HVAC Filters next week' },
  { text: 'Schedule annual physical exam with Dr. Lee in 3 weeks', label: '🩺 Doctor Checkup in 3 weeks' },
];

export const NaturalLanguageInput: React.FC<NaturalLanguageInputProps> = ({
  onAddTask,
  onAddMultipleTasks,
}) => {
  const [prompt, setPrompt] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [isBrainDump, setIsBrainDump] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recentParsedPreview, setRecentParsedPreview] = useState<ParsedTaskResult | null>(null);

  // Handle Voice Dictation using SpeechRecognition if available
  const toggleSpeechRecognition = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      // Fallback: simulate speech capture
      if (!isRecording) {
        setIsRecording(true);
        setTimeout(() => {
          setPrompt('Remind me to renew my car registration in November');
          setIsRecording(false);
        }, 1800);
      } else {
        setIsRecording(false);
      }
      return;
    }

    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsRecording(true);
      recognition.onend = () => setIsRecording(false);
      recognition.onerror = () => setIsRecording(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setPrompt((prev) => (prev ? `${prev} ${transcript}` : transcript));
        setIsRecording(false);
      };

      if (!isRecording) {
        recognition.start();
      } else {
        recognition.stop();
        setIsRecording(false);
      }
    } catch (e) {
      console.warn('Speech recognition error, using simulation', e);
      setIsRecording(false);
    }
  };

  const handleParseAndSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanPrompt = prompt.trim();
    if (!cleanPrompt) return;

    setIsParsing(true);
    const today = getTodayDateString();

    try {
      // Send request to server endpoint
      const response = await fetch('/api/parse-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: cleanPrompt,
          referenceDate: today,
        }),
      });

      const data = await response.json();

      if (data?.tasks && Array.isArray(data.tasks) && data.tasks.length > 0) {
        // Multi or single task from AI
        const newTasks: LifeTask[] = data.tasks.map((parsed: any, idx: number) => {
          const taskDueDate = parsed.dueDate || today;
          // Determine reminder if AI detected reminderSetting or if prompt requested a reminder
          const rawReminderSetting: ReminderSetting = (parsed.reminderSetting && parsed.reminderSetting !== 'none')
            ? (parsed.reminderSetting as ReminderSetting)
            : (/remind me in 2 min|in 2 minutes|in 2 mins|2 minute reminder|2 min reminder|test reminder/i.test(cleanPrompt)
                ? 'in_2_minutes'
                : (/remind me/i.test(cleanPrompt) ? 'on_due_date' : 'none'));
          
          const reminder = rawReminderSetting !== 'none'
            ? createReminderInfo(rawReminderSetting, taskDueDate, parsed.dueTime)
            : undefined;

          return {
            id: `task-${Date.now()}-${idx}-${Math.random().toString(36).substr(2, 5)}`,
            title: parsed.title,
            originalPrompt: cleanPrompt,
            dueDate: taskDueDate,
            dueTime: parsed.dueTime,
            relativeDueLabel: parsed.relativeDueLabel,
            priority: (parsed.priority || 'medium') as Priority,
            category: (parsed.category || 'Other') as LifeCategory,
            status: 'pending',
            estimatedMinutes: parsed.estimatedMinutes || 25,
            recurrence: parsed.recurrence || 'none',
            reminder,
            notes: parsed.notes || `Prompt: "${cleanPrompt}"`,
            checklist: (parsed.checklist || []).map((stepText: string, cIdx: number) => ({
              id: `c-${Date.now()}-${cIdx}`,
              text: stepText,
              completed: false,
            })),
            prepTips: parsed.prepTips || [],
            tags: parsed.tags || [parsed.category?.toLowerCase() || 'admin'],
            createdAt: new Date().toISOString(),
            isSample: false,
            source: 'ai_natural_language',
          };
        });

        if (newTasks.length === 1) {
          onAddTask(newTasks[0]);
          setRecentParsedPreview(data.tasks[0]);
        } else if (onAddMultipleTasks) {
          onAddMultipleTasks(newTasks);
          setRecentParsedPreview(data.tasks[0]);
        }
      } else {
        // Heuristic fallback if AI server returned fallback flag or error
        handleHeuristicFallback(cleanPrompt);
      }
    } catch (err) {
      console.warn('AI Parsing call error, applying local heuristic parser:', err);
      handleHeuristicFallback(cleanPrompt);
    } finally {
      setIsParsing(false);
      setPrompt('');
      setTimeout(() => setRecentParsedPreview(null), 4000);
    }
  };

  const handleHeuristicFallback = (cleanPrompt: string) => {
    // Check if multi-line brain dump
    const lines = cleanPrompt.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    const results: LifeTask[] = [];

    lines.forEach((line, idx) => {
      const parsed = heuristicParseTask(line, new Date());
      const newTask: LifeTask = {
        id: `task-${Date.now()}-${idx}-${Math.random().toString(36).substr(2, 5)}`,
        title: parsed.title,
        originalPrompt: line,
        dueDate: parsed.dueDate,
        dueTime: parsed.dueTime,
        relativeDueLabel: parsed.relativeDueLabel,
        priority: parsed.priority,
        category: parsed.category,
        status: 'pending',
        estimatedMinutes: parsed.estimatedMinutes,
        recurrence: parsed.recurrence || 'none',
        reminder: parsed.reminder,
        notes: parsed.notes,
        checklist: (parsed.checklist || []).map((t, cIdx) => ({
          id: `c-${Date.now()}-${cIdx}`,
          text: t,
          completed: false,
        })),
        prepTips: parsed.prepTips,
        tags: parsed.tags || [],
        createdAt: new Date().toISOString(),
        isSample: false,
        source: 'ai_natural_language',
      };
      results.push(newTask);
    });

    if (results.length === 1) {
      onAddTask(results[0]);
      setRecentParsedPreview(heuristicParseTask(cleanPrompt));
    } else if (onAddMultipleTasks) {
      onAddMultipleTasks(results);
    }
  };

  const handleApplyExample = (text: string) => {
    setPrompt(text);
  };

  return (
    <div className="w-full bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-sm shadow-slate-200/50 dark:shadow-none transition-all">
      {/* Input Header & Mode Switcher */}
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-6 h-6 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-200">
            Natural Language Capture
          </span>
        </div>

        <button
          type="button"
          onClick={() => setIsBrainDump(!isBrainDump)}
          className={`flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-lg transition-all border ${
            isBrainDump
              ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-950/50 dark:border-indigo-800 dark:text-indigo-300 font-medium'
              : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
          }`}
          title="Toggle Multi-line brain dump"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>{isBrainDump ? 'Brain Dump Mode (Multi-task)' : 'Single Task'}</span>
        </button>
      </div>

      {/* Main Input Form */}
      <form onSubmit={handleParseAndSubmit} className="relative">
        <div className="relative flex flex-col sm:flex-row items-stretch rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-950/40 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20 transition-all shadow-inner">
          {isBrainDump ? (
            <textarea
              id="natural-task-textarea"
              rows={4}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Paste multiple tasks or brain dump list, e.g.:&#10;1. Remind me to renew my car registration in November&#10;2. I need to call the dentist next Tuesday&#10;3. Pay quarterly taxes before Sept 15"
              className="w-full bg-transparent p-3.5 text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none resize-none"
            />
          ) : (
            <input
              id="natural-task-input"
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. 'Remind me to renew my car registration in November' or 'Call the dentist next Tuesday'"
              className="w-full bg-transparent px-4 py-3.5 text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none"
            />
          )}

          {/* Action buttons inside the input container */}
          <div className="flex items-center justify-end gap-1.5 p-2 sm:border-l border-slate-200 dark:border-slate-800/80 bg-white/40 dark:bg-slate-900/40 sm:bg-transparent">
            {/* Voice Dictation Button */}
            <button
              type="button"
              id="voice-dictation-btn"
              onClick={toggleSpeechRecognition}
              title={isRecording ? 'Listening... click to stop' : 'Dictate with voice'}
              className={`p-2.5 rounded-lg text-xs transition-all flex items-center justify-center ${
                isRecording
                  ? 'bg-rose-500 text-white animate-pulse shadow-md shadow-rose-500/30'
                  : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* Submit Button */}
            <button
              type="submit"
              id="plot-task-submit-btn"
              disabled={isParsing || !prompt.trim()}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-indigo-600 dark:hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-semibold rounded-lg shadow-sm transition-all whitespace-nowrap"
            >
              {isParsing ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Organizing...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-indigo-300 dark:text-indigo-200" />
                  <span>Plot Task</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-0.5" />
                </>
              )}
            </button>
          </div>
        </div>
      </form>

      {/* Instant Feedback Toast / Preview */}
      {recentParsedPreview && (
        <div className="mt-3 p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 rounded-xl flex items-center justify-between text-xs text-emerald-900 dark:text-emerald-200 animate-in fade-in slide-in-from-top-1 duration-200">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>
              <strong>Added:</strong> {recentParsedPreview.title} &bull; Due{' '}
              <span className="font-semibold">{recentParsedPreview.dueDate}</span> &bull;{' '}
              <span className="capitalize">{recentParsedPreview.category}</span> ({recentParsedPreview.priority} priority)
            </span>
          </div>
          <span className="text-[11px] font-medium text-emerald-700 dark:text-emerald-300">Saved to Dashboard</span>
        </div>
      )}

      {/* Suggested Quick Natural Prompts */}
      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1 mr-1">
          <HelpCircle className="w-3 h-3" /> Quick Examples:
        </span>
        {EXAMPLE_PROMPTS.map((ex, i) => (
          <button
            key={i}
            type="button"
            onClick={() => handleApplyExample(ex.text)}
            className="px-2.5 py-1 text-xs bg-slate-100 dark:bg-slate-800/80 hover:bg-indigo-50 hover:text-indigo-700 dark:hover:bg-indigo-950/60 dark:hover:text-indigo-300 text-slate-700 dark:text-slate-300 rounded-lg border border-slate-200/60 dark:border-slate-700/60 transition-colors"
          >
            {ex.label}
          </button>
        ))}
      </div>
    </div>
  );
};
