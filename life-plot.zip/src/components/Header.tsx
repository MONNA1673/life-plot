import React from 'react';
import { Sparkles, Calendar, CheckCircle2, RotateCcw } from 'lucide-react';
import { LifeTask } from '../types';

interface HeaderProps {
  tasks: LifeTask[];
  onExport: () => void;
  onImport: (tasks: LifeTask[]) => void;
  onResetSampleData: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  tasks = [],
  onResetSampleData,
}) => {
  const safeTasks = Array.isArray(tasks) ? tasks : [];
  const completedCount = safeTasks.filter((t) => t && t.status === 'completed').length;
  const totalCount = safeTasks.length;

  const today = new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  return (
    <header className="border-b border-slate-200/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md sticky top-0 z-30 transition-colors">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Brand & Logo */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-base tracking-tight text-slate-900 dark:text-slate-50 font-serif">
                Life Plot
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Personal life admin assistant
            </p>
          </div>
        </div>

        {/* Right Info: Today's date & status count */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs text-slate-600 dark:text-slate-300 font-medium">
            <Calendar className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            <span>{today}</span>
          </div>

          <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>
              {completedCount}/{totalCount} done
            </span>
          </div>

          <button
            id="reset-sample-btn"
            type="button"
            onClick={onResetSampleData}
            title="Reset sample tasks"
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
