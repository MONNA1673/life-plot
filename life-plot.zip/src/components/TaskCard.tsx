import React from 'react';
import {
  CheckCircle2,
  Circle,
  Calendar,
  Clock,
  Car,
  HeartPulse,
  Landmark,
  Home,
  Users,
  Briefcase,
  FileCheck,
  Compass,
  CheckSquare,
  Trash2,
  Edit3,
  Bell,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { LifeCategory, LifeTask, Priority } from '../types';
import { CATEGORIES_CONFIG } from '../data/categories';
import { formatFriendlyDate, getDateHorizon } from '../utils/dateUtils';
import { formatReminderSummary } from '../utils/reminderUtils';

interface TaskCardProps {
  task: LifeTask;
  onToggleComplete: (taskId: string) => void;
  onDelete: (taskId: string) => void;
  onEdit: (task: LifeTask) => void;
}

const CATEGORY_ICONS: Record<LifeCategory, React.ElementType> = {
  'Vehicles & DMV': Car,
  'Health & Medical': HeartPulse,
  'Finance & Taxes': Landmark,
  'Home & Utilities': Home,
  'Family & Kids': Users,
  'Career & Work': Briefcase,
  'Legal & Admin': FileCheck,
  'Personal & Leisure': Compass,
  'Other': CheckSquare,
};

const PRIORITY_BADGES: Record<Priority, { label: string; bg: string; text: string }> = {
  urgent: { label: 'Urgent', bg: 'bg-rose-50 dark:bg-rose-950/50', text: 'text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-900/60' },
  high: { label: 'High', bg: 'bg-amber-50 dark:bg-amber-950/50', text: 'text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-900/60' },
  medium: { label: 'Medium', bg: 'bg-indigo-50 dark:bg-indigo-950/50', text: 'text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-900/60' },
  low: { label: 'Low', bg: 'bg-slate-50 dark:bg-slate-800/60', text: 'text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700' },
};

export const TaskCard: React.FC<TaskCardProps> = ({
  task,
  onToggleComplete,
  onDelete,
  onEdit,
}) => {
  if (!task) return null;
  const isCompleted = task.status === 'completed';
  const categoryConfig = (task.category && CATEGORIES_CONFIG[task.category]) || CATEGORIES_CONFIG['Other'];
  const IconComponent = (task.category && CATEGORY_ICONS[task.category]) || CheckSquare;
  const horizon = getDateHorizon(task.dueDate);
  const priorityConfig = (task.priority && PRIORITY_BADGES[task.priority]) || PRIORITY_BADGES.medium;

  const handleCheckClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isCompleted) {
      try {
        const confettiFunc = typeof confetti === 'function' ? confetti : (confetti as any)?.default;
        if (typeof confettiFunc === 'function') {
          confettiFunc({
            particleCount: 35,
            spread: 55,
            origin: { y: 0.8 },
            colors: ['#6366f1', '#10b981', '#f59e0b'],
          });
        }
      } catch (err) {
        // ignore
      }
    }
    onToggleComplete(task.id);
  };

  // Due date styling
  let dateBadgeBg = 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700';
  if (!isCompleted) {
    if (horizon === 'overdue') {
      dateBadgeBg = 'bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800 font-semibold';
    } else if (horizon === 'today') {
      dateBadgeBg = 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800 font-semibold';
    } else if (horizon === 'tomorrow' || horizon === 'this_week') {
      dateBadgeBg = 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800';
    }
  }

  return (
    <div
      id={`task-card-${task.id}`}
      className={`group relative p-4 rounded-xl border transition-all duration-150 ${
        isCompleted
          ? 'bg-slate-50/60 dark:bg-slate-900/40 border-slate-200/60 dark:border-slate-800/60 opacity-75'
          : 'bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-800 shadow-xs'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        {/* Left: Checkbox & Info */}
        <div className="flex items-start gap-3 min-w-0 flex-1">
          <button
            id={`toggle-complete-btn-${task.id}`}
            type="button"
            onClick={handleCheckClick}
            className="mt-0.5 shrink-0 rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors"
            title={isCompleted ? 'Mark as incomplete' : 'Mark as complete'}
          >
            {isCompleted ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 fill-emerald-50 dark:fill-emerald-950" />
            ) : (
              <Circle className="w-5 h-5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400" />
            )}
          </button>

          <div className="min-w-0 flex-1">
            {/* Title & Strikethrough */}
            <div className="flex items-baseline gap-2 flex-wrap mb-1">
              <h3
                className={`text-sm font-medium leading-snug transition-colors ${
                  isCompleted
                    ? 'line-through text-slate-400 dark:text-slate-500'
                    : 'text-slate-900 dark:text-slate-100'
                }`}
              >
                {task.title}
              </h3>
            </div>

            {/* Notes if available */}
            {task.notes && (
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-2 line-clamp-2">
                {task.notes}
              </p>
            )}

            {/* Badges: Category, Due Date, Priority */}
            <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
              {/* Category */}
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium border ${categoryConfig.bgColor} ${categoryConfig.textColor} ${categoryConfig.borderColor}`}
              >
                <IconComponent className="w-3 h-3" />
                {categoryConfig.name}
              </span>

              {/* Due Date */}
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] border ${dateBadgeBg}`}
              >
                <Calendar className="w-3 h-3" />
                {formatFriendlyDate(task.dueDate)}
                {task.dueTime && <span className="opacity-80">at {task.dueTime}</span>}
              </span>

              {/* Reminder Alert Badge */}
              {task.reminder?.enabled && task.reminder?.setting !== 'none' && (
                <button
                  type="button"
                  onClick={() => onEdit(task)}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200/80 dark:border-indigo-800/80 transition-colors cursor-pointer"
                  title={`Reminder: ${formatReminderSummary(task.reminder)} (Click to edit)`}
                >
                  <Bell className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />
                  <span>{formatReminderSummary(task.reminder)}</span>
                </button>
              )}

              {/* Priority */}
              <span
                className={`inline-flex items-center px-1.5 py-0.5 rounded-md text-[10px] font-semibold uppercase tracking-wider border ${priorityConfig.bg} ${priorityConfig.text}`}
              >
                {priorityConfig.label}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Actions (Edit, Delete) */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            id={`edit-task-btn-${task.id}`}
            type="button"
            onClick={() => onEdit(task)}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            title="Edit task"
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            id={`delete-task-btn-${task.id}`}
            type="button"
            onClick={() => onDelete(task.id)}
            className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
            title="Delete task"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
