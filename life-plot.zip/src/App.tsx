import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Calendar,
  CheckCircle2,
  Circle,
  Search,
  X,
  Plus,
  RotateCcw,
  SlidersHorizontal,
  Clock,
} from 'lucide-react';
import { Header } from './components/Header';
import { NaturalLanguageInput } from './components/NaturalLanguageInput';
import { TaskCard } from './components/TaskCard';
import { TaskEditModal } from './components/TaskEditModal';
import { ActiveReminderBanner } from './components/ActiveReminderBanner';
import { LifeCategory, LifeTask, Priority } from './types';
import { INITIAL_SAMPLE_TASKS } from './data/initialTasks';
import { ALL_CATEGORIES } from './data/categories';
import { getDateHorizon, getTodayDateString } from './utils/dateUtils';
import {
  calculateReminderDateTime,
  playReminderChime,
  requestBrowserNotificationPermission,
  sendBrowserNotification,
} from './utils/reminderUtils';

const STORAGE_KEY = 'lifeplot_tasks_v1';

type FilterTab = 'all' | 'today' | 'upcoming' | 'completed';

export default function App() {
  // Load tasks from localStorage or initialize with sample data
  const [tasks, setTasks] = useState<LifeTask[]>(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            const valid = parsed.filter(
              (t: any) => t && typeof t === 'object' && typeof t.id === 'string' && typeof t.title === 'string'
            );
            if (valid.length > 0) return valid;
          }
        }
      }
    } catch (e) {
      console.warn('Error loading tasks from localStorage', e);
    }
    return INITIAL_SAMPLE_TASKS;
  });

  // Fetch persisted tasks from server on mount
  useEffect(() => {
    let isMounted = true;
    const fetchServerTasks = async () => {
      try {
        const res = await fetch('/api/tasks');
        if (res.ok) {
          const data = await res.json();
          if (isMounted && data && Array.isArray(data.tasks) && data.tasks.length > 0) {
            setTasks(data.tasks);
            if (typeof window !== 'undefined' && window.localStorage) {
              localStorage.setItem(STORAGE_KEY, JSON.stringify(data.tasks));
            }
          }
        }
      } catch (err) {
        console.warn('Server task fetch deferred, using cached tasks:', err);
      }
    };
    fetchServerTasks();
    return () => {
      isMounted = false;
    };
  }, []);

  // Save tasks to localStorage on change
  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
      }
    } catch (e) {
      console.warn('Error saving tasks to localStorage', e);
    }
  }, [tasks]);

  // Dashboard filtering state
  const [activeFilterTab, setActiveFilterTab] = useState<FilterTab>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<LifeCategory | 'all'>('all');

  // Edit modal state
  const [editingTask, setEditingTask] = useState<LifeTask | null>(null);

  // Active fired reminders state
  const [activeReminders, setActiveReminders] = useState<LifeTask[]>([]);
  const alertedTaskIdsRef = React.useRef<Set<string>>(new Set());

  // Check for due reminders periodically (every 15 seconds)
  useEffect(() => {
    // Request permission once on interaction if possible
    requestBrowserNotificationPermission();

    const checkReminders = () => {
      const now = Date.now();
      const newlyDue: LifeTask[] = [];

      tasks.forEach((task) => {
        if (!task || task.status === 'completed') return;
        const reminder = task.reminder;
        if (!reminder || !reminder.enabled || reminder.setting === 'none' || reminder.dismissed) {
          return;
        }

        // Determine target time
        let triggerTime: number | null = null;
        if (reminder.snoozedUntil) {
          triggerTime = new Date(reminder.snoozedUntil).getTime();
        } else if (reminder.reminderDateTime) {
          triggerTime = new Date(reminder.reminderDateTime).getTime();
        } else {
          const calcIso = calculateReminderDateTime(task.dueDate, task.dueTime, reminder.setting);
          if (calcIso) triggerTime = new Date(calcIso).getTime();
        }

        if (triggerTime && triggerTime <= now) {
          newlyDue.push(task);

          // If not previously alerted in this session, trigger sound and browser notification
          if (!alertedTaskIdsRef.current.has(task.id)) {
            alertedTaskIdsRef.current.add(task.id);
            playReminderChime();
            sendBrowserNotification(
              `Reminder: ${task.title}`,
              `Due ${task.dueDate}${task.dueTime ? ` at ${task.dueTime}` : ''} • ${task.category}`
            );
          }
        }
      });

      setActiveReminders(newlyDue);
    };

    checkReminders();
    const interval = setInterval(checkReminders, 1000);
    return () => clearInterval(interval);
  }, [tasks]);

  const handleDismissReminder = (taskId: string) => {
    let updatedTaskPayload: LifeTask | null = null;
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updated: LifeTask = {
            ...t,
            reminder: {
              ...t.reminder!,
              dismissed: true,
              remindedAt: new Date().toISOString(),
            },
          };
          updatedTaskPayload = updated;
          return updated;
        }
        return t;
      })
    );

    setActiveReminders((prev) => prev.filter((t) => t.id !== taskId));

    if (updatedTaskPayload) {
      fetch(`/api/tasks/${taskId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedTaskPayload),
      }).catch((err) => console.warn('Failed to sync reminder dismissal:', err));
    }
  };

  const handleSnoozeReminder = (taskId: string, minutes: number = 60) => {
    const snoozedUntil = new Date(Date.now() + minutes * 60000).toISOString();
    let updatedTaskPayload: LifeTask | null = null;

    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updated: LifeTask = {
            ...t,
            reminder: {
              ...t.reminder!,
              snoozedUntil,
              dismissed: false,
            },
          };
          updatedTaskPayload = updated;
          return updated;
        }
        return t;
      })
    );

    alertedTaskIdsRef.current.delete(taskId);
    setActiveReminders((prev) => prev.filter((t) => t.id !== taskId));

    if (updatedTaskPayload) {
      fetch(`/api/tasks/${taskId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedTaskPayload),
      }).catch((err) => console.warn('Failed to sync reminder snooze:', err));
    }
  };

  const handleCompleteReminderTask = (taskId: string) => {
    handleToggleComplete(taskId);
    setActiveReminders((prev) => prev.filter((t) => t.id !== taskId));
  };

  // Handlers for task mutations
  const handleAddTask = (newTask: LifeTask) => {
    if (!newTask) return;
    if (newTask.id) alertedTaskIdsRef.current.delete(newTask.id);
    setTasks((prev) => [newTask, ...prev]);

    // Persist to server
    fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTask),
    }).catch((err) => console.warn('Failed to sync new task to server:', err));
  };

  const handleAddMultipleTasks = (newTasks: LifeTask[]) => {
    if (!Array.isArray(newTasks) || newTasks.length === 0) return;
    newTasks.forEach((t) => {
      if (t.id) alertedTaskIdsRef.current.delete(t.id);
    });
    setTasks((prev) => [...newTasks, ...prev]);

    // Persist to server
    fetch('/api/tasks/bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tasks: newTasks }),
    }).catch((err) => console.warn('Failed to sync bulk tasks to server:', err));
  };

  const handleToggleComplete = (taskId: string) => {
    let updatedTaskPayload: Partial<LifeTask> | null = null;
    setTasks((prev) =>
      prev.map((t) => {
        if (t && t.id === taskId) {
          const isNowCompleted = t.status !== 'completed';
          const updated = {
            ...t,
            status: (isNowCompleted ? 'completed' : 'pending') as 'completed' | 'pending',
            completedAt: isNowCompleted ? new Date().toISOString() : undefined,
          };
          updatedTaskPayload = updated;
          return updated;
        }
        return t;
      })
    );

    if (updatedTaskPayload) {
      fetch(`/api/tasks/${taskId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedTaskPayload),
      }).catch((err) => console.warn('Failed to sync toggle to server:', err));
    }
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t && t.id !== taskId));

    // Persist to server
    fetch(`/api/tasks/${taskId}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Failed to delete task on server:', err));
  };

  const handleSaveEditedTask = (updatedTask: LifeTask) => {
    if (!updatedTask) return;
    if (updatedTask.id) alertedTaskIdsRef.current.delete(updatedTask.id);
    setTasks((prev) => prev.map((t) => (t && t.id === updatedTask.id ? updatedTask : t)));
    setEditingTask(null);

    // Persist to server
    fetch(`/api/tasks/${updatedTask.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedTask),
    }).catch((err) => console.warn('Failed to sync edited task to server:', err));
  };

  const handleResetSampleData = async () => {
    // Keep user-created tasks while resetting sample tasks
    const userTasks = safeTasks.filter((t) => t.isSample === false && !t.id.startsWith('task-sample-'));
    const freshSamples = INITIAL_SAMPLE_TASKS.map((t) => ({ ...t, isSample: true, source: 'sample' as const }));
    const merged = [...userTasks, ...freshSamples];
    setTasks(merged);

    // Persist reset to server
    try {
      const res = await fetch('/api/tasks/reset', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data && Array.isArray(data.tasks)) {
          setTasks(data.tasks);
        }
      }
    } catch (err) {
      console.warn('Failed to reset tasks on server:', err);
    }
  };

  const handleExportBackup = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(tasks, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `lifeplot-backup-${getTodayDateString()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportBackup = (importedTasks: LifeTask[]) => {
    if (Array.isArray(importedTasks) && importedTasks.length > 0) {
      setTasks(importedTasks);

      // Persist full sync to server
      fetch('/api/tasks/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tasks: importedTasks }),
      }).catch((err) => console.warn('Failed to sync imported tasks to server:', err));
    }
  };

  const safeTasks = Array.isArray(tasks) ? tasks.filter(Boolean) : [];

  // Counts
  const todayOrOverdueCount = safeTasks.filter((t) => {
    if (t.status === 'completed') return false;
    const h = getDateHorizon(t.dueDate);
    return h === 'overdue' || h === 'today';
  }).length;

  const upcomingCount = safeTasks.filter((t) => {
    if (t.status === 'completed') return false;
    const h = getDateHorizon(t.dueDate);
    return h !== 'overdue' && h !== 'today';
  }).length;

  const completedCount = safeTasks.filter((t) => t.status === 'completed').length;
  const totalActiveCount = safeTasks.filter((t) => t.status !== 'completed').length;

  // Filter tasks based on search & category & tab
  const filteredTasks = safeTasks.filter((task) => {
    if (!task) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = (task.title || '').toLowerCase().includes(q);
      const matchNotes = (task.notes || '').toLowerCase().includes(q);
      const matchCategory = (task.category || '').toLowerCase().includes(q);
      if (!matchTitle && !matchNotes && !matchCategory) return false;
    }

    // Category filter
    if (categoryFilter !== 'all' && task.category !== categoryFilter) {
      return false;
    }

    // Tab filter
    if (activeFilterTab === 'completed') {
      return task.status === 'completed';
    }

    if (activeFilterTab === 'today') {
      if (task.status === 'completed') return false;
      const h = getDateHorizon(task.dueDate);
      return h === 'overdue' || h === 'today';
    }

    if (activeFilterTab === 'upcoming') {
      if (task.status === 'completed') return false;
      const h = getDateHorizon(task.dueDate);
      return h !== 'overdue' && h !== 'today';
    }

    // 'all' tab: keep all tasks (we will group or show active first)
    return true;
  });

  // Separate into groups for 'all' tab or display directly
  const activeTodayTasks = filteredTasks.filter(
    (t) => t.status !== 'completed' && (getDateHorizon(t.dueDate) === 'overdue' || getDateHorizon(t.dueDate) === 'today')
  );

  const activeUpcomingTasks = filteredTasks.filter(
    (t) => t.status !== 'completed' && getDateHorizon(t.dueDate) !== 'overdue' && getDateHorizon(t.dueDate) !== 'today'
  );

  const completedTasksList = filteredTasks.filter((t) => t.status === 'completed');

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <Header
        tasks={tasks}
        onExport={handleExportBackup}
        onImport={handleImportBackup}
        onResetSampleData={handleResetSampleData}
      />

      {/* Main Task Dashboard Container */}
      <main className="max-w-4xl mx-auto w-full px-4 sm:px-6 py-6 sm:py-8 flex-1 space-y-6">
        {/* Natural Language Task Input */}
        <section>
          <NaturalLanguageInput
            onAddTask={handleAddTask}
            onAddMultipleTasks={handleAddMultipleTasks}
          />
        </section>

        {/* Filter Tabs & Search Controls */}
        <section className="space-y-3 pt-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
              <button
                id="filter-tab-all"
                type="button"
                onClick={() => setActiveFilterTab('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  activeFilterTab === 'all'
                    ? 'bg-slate-900 dark:bg-indigo-600 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                }`}
              >
                All Tasks ({tasks.length})
              </button>

              <button
                id="filter-tab-today"
                type="button"
                onClick={() => setActiveFilterTab('today')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                  activeFilterTab === 'today'
                    ? 'bg-amber-500 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                }`}
              >
                <span>Today & Overdue</span>
                {todayOrOverdueCount > 0 && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                      activeFilterTab === 'today' ? 'bg-amber-600 text-white' : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                    }`}
                  >
                    {todayOrOverdueCount}
                  </span>
                )}
              </button>

              <button
                id="filter-tab-upcoming"
                type="button"
                onClick={() => setActiveFilterTab('upcoming')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  activeFilterTab === 'upcoming'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                }`}
              >
                Upcoming ({upcomingCount})
              </button>

              <button
                id="filter-tab-completed"
                type="button"
                onClick={() => setActiveFilterTab('completed')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  activeFilterTab === 'completed'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
                }`}
              >
                Completed ({completedCount})
              </button>
            </div>

            {/* Search and Domain Select */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1 sm:w-48">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  id="task-search-input"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search tasks..."
                  className="w-full pl-8 pr-7 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              <select
                id="task-category-filter-select"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value as any)}
                className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="all">All Domains</option>
                {ALL_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </section>

        {/* Task List Sections */}
        <section className="space-y-6">
          {filteredTasks.length === 0 ? (
            /* Empty State */
            <div className="py-16 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 shadow-xs">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto mb-3">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                {activeFilterTab === 'completed'
                  ? 'No completed tasks yet'
                  : 'No tasks found'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1">
                {searchQuery || categoryFilter !== 'all'
                  ? 'Try clearing your search query or domain filters.'
                  : 'Use natural language above to quickly capture reminders, appointments, and life admin tasks.'}
              </p>
            </div>
          ) : activeFilterTab === 'all' ? (
            /* Grouped View for 'All' Tab */
            <div className="space-y-6">
              {/* Today & Overdue Section */}
              {activeTodayTasks.length > 0 && (
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                      Today & Overdue ({activeTodayTasks.length})
                    </h2>
                  </div>
                  <div className="grid grid-cols-1 gap-2.5">
                    {activeTodayTasks.map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onToggleComplete={handleToggleComplete}
                        onDelete={handleDeleteTask}
                        onEdit={setEditingTask}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Upcoming Section */}
              {activeUpcomingTasks.length > 0 && (
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-indigo-500" />
                      Upcoming ({activeUpcomingTasks.length})
                    </h2>
                  </div>
                  <div className="grid grid-cols-1 gap-2.5">
                    {activeUpcomingTasks.map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onToggleComplete={handleToggleComplete}
                        onDelete={handleDeleteTask}
                        onEdit={setEditingTask}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Completed Section (in 'all' view) */}
              {completedTasksList.length > 0 && (
                <div className="space-y-2.5 pt-2 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      Completed ({completedTasksList.length})
                    </h2>
                  </div>
                  <div className="grid grid-cols-1 gap-2.5">
                    {completedTasksList.map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onToggleComplete={handleToggleComplete}
                        onDelete={handleDeleteTask}
                        onEdit={setEditingTask}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Single list for specific filter tab ('today', 'upcoming', or 'completed') */
            <div className="grid grid-cols-1 gap-2.5">
              {filteredTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onToggleComplete={handleToggleComplete}
                  onDelete={handleDeleteTask}
                  onEdit={setEditingTask}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Task Edit Modal */}
      <TaskEditModal
        task={editingTask}
        isOpen={!!editingTask}
        onClose={() => setEditingTask(null)}
        onSave={handleSaveEditedTask}
      />

      {/* Active Fired Reminders Notification Banner */}
      <ActiveReminderBanner
        reminders={activeReminders}
        onDismiss={handleDismissReminder}
        onSnooze={handleSnoozeReminder}
        onComplete={handleCompleteReminderTask}
      />

      {/* Clean Minimalist Footer */}
      <footer className="border-t border-slate-200/80 dark:border-slate-800 py-4 bg-white dark:bg-slate-900/60 mt-12 transition-colors">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 flex items-center justify-between text-xs text-slate-400 dark:text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700 dark:text-slate-300 font-serif">Life Plot</span>
            <span>&bull;</span>
            <span>Natural language personal task organizer</span>
          </div>
          <div>
            Powered by Gemini
          </div>
        </div>
      </footer>
    </div>
  );
}
