import { LifeCategory } from '../types';

export interface CategoryInfo {
  id: LifeCategory;
  name: string;
  iconName: string;
  color: string; // Tailwind color classes for badges
  bgColor: string;
  textColor: string;
  borderColor: string;
  description: string;
}

export const CATEGORIES_CONFIG: Record<LifeCategory, CategoryInfo> = {
  'Vehicles & DMV': {
    id: 'Vehicles & DMV',
    name: 'Vehicles & DMV',
    iconName: 'Car',
    color: 'amber',
    bgColor: 'bg-amber-500/10',
    textColor: 'text-amber-700 dark:text-amber-300',
    borderColor: 'border-amber-500/20',
    description: 'Registration, smog check, oil changes, insurance, driver license',
  },
  'Health & Medical': {
    id: 'Health & Medical',
    name: 'Health & Medical',
    iconName: 'HeartPulse',
    color: 'emerald',
    bgColor: 'bg-emerald-500/10',
    textColor: 'text-emerald-700 dark:text-emerald-300',
    borderColor: 'border-emerald-500/20',
    description: 'Dentist, doctor visits, Rx refills, eye exams, therapy',
  },
  'Finance & Taxes': {
    id: 'Finance & Taxes',
    name: 'Finance & Taxes',
    iconName: 'Landmark',
    color: 'blue',
    bgColor: 'bg-blue-500/10',
    textColor: 'text-blue-700 dark:text-blue-300',
    borderColor: 'border-blue-500/20',
    description: 'Quarterly taxes, W-2s, insurance policies, mortgages, budgets',
  },
  'Home & Utilities': {
    id: 'Home & Utilities',
    name: 'Home & Utilities',
    iconName: 'Home',
    color: 'teal',
    bgColor: 'bg-teal-500/10',
    textColor: 'text-teal-700 dark:text-teal-300',
    borderColor: 'border-teal-500/20',
    description: 'HVAC maintenance, filters, plumbing, repairs, subscriptions',
  },
  'Family & Kids': {
    id: 'Family & Kids',
    name: 'Family & Kids',
    iconName: 'Users',
    color: 'purple',
    bgColor: 'bg-purple-500/10',
    textColor: 'text-purple-700 dark:text-purple-300',
    borderColor: 'border-purple-500/20',
    description: 'School forms, daycare, pediatric visits, activities, birthdays',
  },
  'Career & Work': {
    id: 'Career & Work',
    name: 'Career & Work',
    iconName: 'Briefcase',
    color: 'indigo',
    bgColor: 'bg-indigo-500/10',
    textColor: 'text-indigo-700 dark:text-indigo-300',
    borderColor: 'border-indigo-500/20',
    description: 'Certifications, performance reviews, expense reports, resumes',
  },
  'Legal & Admin': {
    id: 'Legal & Admin',
    name: 'Legal & Admin',
    iconName: 'FileCheck',
    color: 'rose',
    bgColor: 'bg-rose-500/10',
    textColor: 'text-rose-700 dark:text-rose-300',
    borderColor: 'border-rose-500/20',
    description: 'Passport renewals, notary, leases, contracts, warranties',
  },
  'Personal & Leisure': {
    id: 'Personal & Leisure',
    name: 'Personal & Leisure',
    iconName: 'Compass',
    color: 'sky',
    bgColor: 'bg-sky-500/10',
    textColor: 'text-sky-700 dark:text-sky-300',
    borderColor: 'border-sky-500/20',
    description: 'Travel prep, reservations, fitness goals, personal projects',
  },
  'Other': {
    id: 'Other',
    name: 'Other Life Admin',
    iconName: 'CheckSquare',
    color: 'zinc',
    bgColor: 'bg-zinc-500/10',
    textColor: 'text-zinc-700 dark:text-zinc-300',
    borderColor: 'border-zinc-500/20',
    description: 'General miscellaneous errands and personal tasks',
  },
};

export const ALL_CATEGORIES = Object.keys(CATEGORIES_CONFIG) as LifeCategory[];
