export type Priority = 'urgent' | 'high' | 'medium' | 'low';

export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'snoozed';

export type LifeCategory = 
  | 'Vehicles & DMV'
  | 'Health & Medical'
  | 'Finance & Taxes'
  | 'Home & Utilities'
  | 'Family & Kids'
  | 'Career & Work'
  | 'Personal & Leisure'
  | 'Legal & Admin'
  | 'Other';

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

export type ReminderSetting = 'none' | 'in_2_minutes' | 'on_due_date' | '1_day_before' | '1_hour_before' | 'custom';

export interface ReminderInfo {
  enabled: boolean;
  setting: ReminderSetting;
  reminderDateTime?: string; // ISO timestamp for when the reminder fires
  customTime?: string; // e.g. "09:00"
  remindedAt?: string;
  dismissed?: boolean;
  snoozedUntil?: string;
}

export interface LifeTask {
  id: string;
  title: string;
  originalPrompt?: string;
  dueDate: string; // YYYY-MM-DD
  dueTime?: string; // HH:mm or undefined
  relativeDueLabel?: string;
  priority: Priority;
  category: LifeCategory;
  status: TaskStatus;
  estimatedMinutes: number;
  recurrence?: 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  reminder?: ReminderInfo;
  notes?: string;
  checklist: ChecklistItem[];
  prepTips?: string[];
  tags: string[];
  createdAt: string;
  completedAt?: string;
  isSample?: boolean;
  source?: 'ai_natural_language' | 'manual' | 'preset' | 'user' | 'sample';
}

export interface ParsedTaskResult {
  title: string;
  dueDate: string;
  dueTime?: string;
  relativeDueLabel?: string;
  priority: Priority;
  category: LifeCategory;
  estimatedMinutes: number;
  recurrence?: 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  reminder?: ReminderInfo;
  notes?: string;
  checklist?: string[];
  prepTips?: string[];
  tags?: string[];
}

export interface TaskFilterOptions {
  searchQuery: string;
  category: LifeCategory | 'all';
  priority: Priority | 'all';
  status: 'all' | 'active' | 'completed' | 'today' | 'upcoming';
  sortBy: 'dueDate' | 'priority' | 'createdAt' | 'category';
  sortDirection: 'asc' | 'desc';
}
